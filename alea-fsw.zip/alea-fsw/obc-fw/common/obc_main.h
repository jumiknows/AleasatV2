/**
 * @file obc_main.h
 * @brief Entry point for the firmware
 */

#ifndef OBC_MAIN_H_
#define OBC_MAIN_H_

void obc_main(void);

#endif // OBC_MAIN_H_
