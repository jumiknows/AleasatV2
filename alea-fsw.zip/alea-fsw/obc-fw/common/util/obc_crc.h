/**
 * @file obc_crc.h
 * @brief CRC32 & CRC16 module
 */

#ifndef OBC_CRC__H
#define OBC_CRC__H

/******************************************************************************/
/*                              I N C L U D E S                               */
/******************************************************************************/

// Standard Library
#include <stdlib.h>
#include <stdint.h>

/******************************************************************************/
/*                               D E F I N E S                                */
/******************************************************************************/

#define CRC16_SEED  0xFFFF
#define CRC32_SEED  0xFFFFFFFF

/******************************************************************************/
/*                             F U N C T I O N S                              */
/******************************************************************************/

uint32_t crc_32_buf(uint32_t crc, const void *data_buf, size_t data_len);

uint16_t crc_16_buf(uint16_t crc, const void *data_buf, size_t data_len);

#endif /* OBC_CRC__H */
